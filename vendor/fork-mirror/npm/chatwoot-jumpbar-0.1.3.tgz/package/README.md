# jumpbar

Press ⌘K, type a few letters, pick an action. jumpbar is the command palette
behind the Chatwoot dashboard, packaged so any Vue 3 app can use it, and any
JavaScript app can use its ranking core.

It is small: the ranking core is plain JavaScript with no dependencies (about
1 KB gzipped); the shell is a native `<dialog>` rendered with Tailwind
utilities (about 5 KB gzipped with the core).

- Fuzzy matching with accent folding, sections, nested pages and prefixes
- Frecency so the things you use rise to the top
- Sync `commands` sources ranked on every keystroke, async `search` sources
  with per-source debounce, minimum query length and `AbortSignal`
- Keyboard and pointer handling, open/close motion, skeleton rows while
  remote results load, RTL and IME aware

How it fits together: your app describes what it can do through _sources_,
plain objects with a title and a `run` function. jumpbar ranks them against
what the user typed, and the shell draws the list. The package knows nothing
about your product.

The [guide](docs/guide.md) walks through configuration, Vue usage, plain
JavaScript usage and the full reference. This README is the short version.

## Install

```sh
pnpm add @chatwoot/jumpbar
```

The package ships compiled ES modules with TypeScript declarations; Vue
stays external. `vue` 3.4 or newer is needed for the shell.

### Any framework

The ranking core has no framework dependency. React, Svelte, Solid or plain
JavaScript projects import it from `@chatwoot/jumpbar/core` and render their
own list:

```js
import { rank, groupBySection, createFrecency } from '@chatwoot/jumpbar/core';

const ranked = rank(items, { text: query, scopes: ['conversation'] });
const sections = groupBySection(ranked);
```

The `CommandBar` shell and `useCommandBar` state are Vue 3.

## Styling

The shell is built from Tailwind utilities and reads every colour from a
small set of semantic tokens, so it adapts to any design system.

1. Add the preset and scan the package so its classes are generated:

   ```js
   // tailwind.config.js
   module.exports = {
     presets: [require('@chatwoot/jumpbar/tailwind')],
     content: ['./node_modules/@chatwoot/jumpbar/dist/*.js'],
   };
   ```

   The preset registers the `jumpbar-*` colours as CSS variables and the
   open and close keyframes.

2. Theme it. Either import the neutral defaults and override what you like
   (dark values apply under a `dark` class on the root element):

   ```js
   import '@chatwoot/jumpbar/theme.css';
   ```

   ```css
   :root {
     --jumpbar-primary: #2781f6;
   }
   ```

   or skip the import and map the tokens onto your existing Tailwind colours,
   which also carries your dark mode along:

   ```js
   theme: {
     extend: {
       colors: {
         jumpbar: {
           background: colors.surface,
           foreground: colors.text,
           primary: colors.brand,
         },
       },
     },
   },
   ```

   | Token               | Used for                                          |
   | ------------------- | ------------------------------------------------- |
   | `background`        | Panel                                             |
   | `foreground`        | Titles and input text                             |
   | `muted-foreground`  | Subtitles, section labels, breadcrumbs, badges    |
   | `subtle-foreground` | Placeholder, icons, hints, chevrons               |
   | `muted`             | Active row, chips, avatar fallback, skeleton rows |
   | `subtle`            | Key caps, lighter skeleton bar                    |
   | `border`            | Dividers and key cap outline                      |
   | `ring`              | Panel outline                                     |
   | `primary`           | Active row marker, page chip text                 |
   | `primary-soft`      | Page chip background                              |
   | `overlay`           | Backdrop                                          |
   | `online` `busy` `offline` | Presence dot                                |

3. Provide the icon classes `i-lucide-search`, `i-lucide-loader-circle` and
   `i-lucide-chevron-right` (for example through `@egoist/tailwindcss-icons`
   with the Lucide set). Items bring their own icon class.

## Quick start

Four steps, all shown in the example below:

1. Add the Tailwind preset and theme the tokens (see Styling above).
2. Render `<CommandBar />` once, near the root of your app, and get the shared
   state with `useCommandBar()`.
3. Register sources: `commands` for things you already know about, `search`
   for things you fetch while the user types.
4. Bind your shortcut and call `bar.toggle()`.

```vue
<script setup>
import { CommandBar, createFrecency, useCommandBar } from '@chatwoot/jumpbar';

const bar = useCommandBar();

bar.configure({
  prefixes: ['@', '#'],
  context: () => ({ scopes: ['conversation'] }),
  frecency: createFrecency({ storage: localStorage, key: 'palette-usage' }),
  onSelect: item => track(item),
  onClose: () => {},
  onError: (error, source) => report(error),
  limit: 100,
});

bar.register({
  id: 'navigation',
  commands: () => [
    {
      id: 'inbox',
      title: 'Go to inbox',
      section: 'Navigation',
      icon: 'i-lucide-inbox',
      shortcut: ['⌥', 'I'],
      run: () => router.push('/inbox'),
    },
  ],
});

bar.register({
  id: 'contacts',
  minQuery: 3,
  debounce: 300,
  when: ({ page }) => !page,
  search: async ({ text, signal }) => {
    const contacts = await api.search(text, { signal });
    return contacts.map(contact => ({
      id: `contact-${contact.id}`,
      title: contact.name,
      subtitle: contact.email,
      section: 'Contacts',
      avatar: { name: contact.name, src: contact.thumbnail },
      run: () => router.push(`/contacts/${contact.id}`),
    }));
  },
});
</script>

<template>
  <CommandBar
    placeholder="Search or jump to"
    empty-text="No matches"
    :hints="[
      { keys: ['↑', '↓'], label: 'navigate' },
      { keys: ['↵'], label: 'select' },
      { keys: ['esc'], label: 'close' },
    ]"
  />
</template>
```

Bind the global shortcut yourself and call `bar.toggle()`. `bar.open({ page,
query })` opens straight into a page, for example a snooze picker.

`CommandBar` props: `placeholder`, `emptyText`, `scopeLabel` (a chip before the
input, for example the selected record), `hints` and `dir` (`ltr` or `rtl`).

## Items

Sources return plain objects:

| Field            | Meaning                                                                  |
| ---------------- | ------------------------------------------------------------------------ |
| `id`             | Unique across all sources. Frecency and dedupe key on it.                |
| `title`          | Row label. Children are matched through `parentTitle title` too.         |
| `subtitle`       | Muted text after the title. Takes only the space left after the breadcrumb and title. |
| `section`        | Group header. With nothing typed, groups keep source order; with text, the best match leads. |
| `icon`           | CSS class rendered as the leading glyph.                                 |
| `avatar`         | `{ name, src, status }` instead of the icon, initials as fallback; `status` is `online`, `busy` or `offline`. |
| `badge`          | Short trailing text.                                                     |
| `shortcut`       | Trailing key labels, for example `['⌥', 'E']`. Alternatives as nested lists: `[['⌥', 'J'], ['⌥', 'K']]`.                           |
| `keywords`       | Extra words the matcher sees (word-start matches only).                  |
| `scopes`         | Ranks first when one matches `context.scopes`.                           |
| `prefix`         | Typing this character first lists only items carrying it.                |
| `weight`         | Static boost between 0 and 1.                                            |
| `place`          | `first` or `last`: sorts around every other match, in declared order.    |
| `searchFromRoot` | `false` keeps a child out of root searches (prefix and page only).       |
| `page`           | Selecting opens a page listing the items whose `parent` is its id.       |
| `placeholder`    | Input placeholder while that page is open.                               |
| `parent`         | Id of the page this item lives under.                                    |
| `run`            | Called with the context as the bar starts closing; the dialog leaves the top layer about 150 ms later. Rows without it are inert. |

## Sources

```js
bar.register({
  id: 'conversations',
  minQuery: 2,
  debounce: 300,
  when: ({ page }) => !page,
  commands: request => [],
  search: async request => [],
});
```

`commands` runs on every keystroke and is ranked. `search` runs after the
debounce with an `AbortSignal`; its results keep their own order, append after
the ranked commands at the root, and replace the static children on a page.
The request carries `query`, `text`, `prefix`, `page`, `context` and, for
`search`, `matches` (how many commands matched locally) and `signal`.
`register` returns a function that removes the source again. A searcher that
throws has its rows dropped and `onError(error, source)` called; the default
rethrows. Text queries show at most `limit` ranked commands (default 50).

## Ranking

Titles match by exact, prefix, word start, every-word-starts-a-word, then
scattered characters. Spaces, hyphens, underscores and slashes separate words.
Subtitles and keywords only match on word starts, so a long description never
floods the list. Items in `context.scopes` get a boost, recently used items
another, `weight` a small static one. A word match always ranks above a
mid-word one, and scattered-character matches are a fallback: they are listed
only when nothing matches properly. `place: 'first'` and `place: 'last'` sit
outside the scoring entirely.

## Keyboard

`↑` `↓` move, `⌘`/`Ctrl` + `↑` `↓` jump to the first or last row, `Enter` selects, `Esc` closes, `Backspace` on an empty query goes
back one page. Hover only changes the selection when the pointer really moves,
so arrow keys keep working under a resting cursor.

## Development

```sh
pnpm install
pnpm test
pnpm build
```

Source lives in `src/` with specs next to it; `dist/` is built on publish and
is not committed. To release, bump `version` in `package.json` and run
`pnpm publish`. The `prepublishOnly` script builds and runs the tests first,
so a broken build never reaches the registry.
