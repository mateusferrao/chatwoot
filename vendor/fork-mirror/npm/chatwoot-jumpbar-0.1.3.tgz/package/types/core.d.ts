export type Context = { scopes?: string[] } & Record<string, unknown>;

export interface Avatar {
  name: string;
  src?: string | null;
  status?: 'online' | 'busy' | 'offline';
}

export interface Item {
  id: string;
  title: string;
  subtitle?: string;
  section?: string;
  icon?: string;
  avatar?: Avatar;
  badge?: string;
  shortcut?: string[] | string[][];
  keywords?: string[];
  scopes?: string[];
  prefix?: string;
  weight?: number;
  place?: 'first' | 'last';
  searchFromRoot?: boolean;
  page?: boolean;
  placeholder?: string;
  parent?: string;
  run?: (context: Context) => void;
}

export interface RankedItem extends Item {
  parentTitle?: string;
}

export interface Section<T extends Item = RankedItem> {
  section: string | null;
  items: T[];
}

export interface Frecency {
  record(id: string): void;
  score(id: string): number;
}

export interface FrecencyStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export interface FrecencyOptions {
  storage: FrecencyStorage;
  key: string;
  now?: () => number;
  limit?: number;
}

export interface RankOptions {
  text?: string;
  prefix?: string | null;
  page?: string | null;
  scopes?: string[];
  frecency?: Pick<Frecency, 'score'>;
}

export function normalize(value: unknown): string;
export function fuzzyScore(
  query: string,
  text: string,
  options?: { subsequence?: boolean }
): number;
export function parseQuery(
  input: string,
  prefixes?: string[]
): { prefix: string | null; text: string };
export function createFrecency(options: FrecencyOptions): Frecency;
export function rank(items: Item[], options: RankOptions): RankedItem[];
export function groupBySection<T extends Item>(items: T[]): Section<T>[];
