import type { ComputedRef, DefineComponent, Ref } from 'vue';
import type { Context, Frecency, Item, RankedItem, Section } from './core';

export * from './core';

export interface Request {
  query: string;
  text: string;
  prefix: string | null;
  page: string | null;
  context: Context;
}

export interface SearchRequest extends Request {
  matches: number;
  signal: AbortSignal;
}

export interface Source {
  id: string;
  minQuery?: number;
  debounce?: number;
  when?: (request: Request | SearchRequest) => boolean;
  commands?: (request: Request) => Item[];
  search?: (request: SearchRequest) => Promise<Item[]> | Item[];
}

export interface CommandBarOptions {
  prefixes?: string[];
  context?: () => Context;
  frecency?: Frecency;
  onSelect?: (item: Item) => void;
  onClose?: () => void;
  onError?: (error: unknown, source: Source) => void;
  debounce?: number;
  limit?: number;
}

export interface CommandBarInstance {
  isOpen: Ref<boolean>;
  query: Ref<string>;
  page: ComputedRef<Item | null>;
  pages: Ref<Item[]>;
  visible: ComputedRef<RankedItem[]>;
  sections: ComputedRef<Section[]>;
  selectedIndex: Ref<number>;
  selected: ComputedRef<RankedItem | null>;
  isLoading: ComputedRef<boolean>;
  open(options?: { page?: string | null; query?: string }): void;
  close(): void;
  toggle(): void;
  back(): void;
  select(item: Item | null | undefined): void;
  setQuery(value: string): void;
  moveSelection(delta: number): void;
  jumpSelection(delta: number): void;
  register(source: Source): () => void;
  configure(overrides: CommandBarOptions): void;
  dispose(): void;
}

export function createCommandBar(
  options?: CommandBarOptions
): CommandBarInstance;
export function useCommandBar(): CommandBarInstance;

export interface Hint {
  keys: string[];
  label: string;
}

export interface CommandBarProps {
  placeholder?: string;
  emptyText?: string;
  scopeLabel?: string;
  hints?: Hint[];
  dir?: 'ltr' | 'rtl';
}

export const CommandBar: DefineComponent<CommandBarProps>;
