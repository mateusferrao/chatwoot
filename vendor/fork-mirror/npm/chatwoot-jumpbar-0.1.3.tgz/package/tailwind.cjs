const TOKENS = [
  'background',
  'foreground',
  'muted-foreground',
  'subtle-foreground',
  'muted',
  'subtle',
  'border',
  'ring',
  'primary',
  'primary-soft',
  'overlay',
  'online',
  'busy',
  'offline',
];

module.exports = {
  theme: {
    extend: {
      colors: {
        jumpbar: Object.fromEntries(
          TOKENS.map(name => [name, `var(--jumpbar-${name})`])
        ),
      },
      keyframes: {
        'command-bar-in': {
          from: { transform: 'scale(0.96) translateY(0.25rem)' },
        },
        'fade-in': {
          '0%': { opacity: 0 },
        },
        'fade-in-up': {
          '0%': { opacity: 0, transform: 'translateY(0.5rem)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        'command-bar-out': {
          from: { opacity: 1, transform: 'scale(1) translateY(0)' },
          to: { opacity: 0, transform: 'scale(0.92) translateY(0.5rem)' },
        },
        'fade-out': {
          to: { opacity: 0 },
        },
      },
      animation: {
        'command-bar-in':
          'command-bar-in 0.3s linear(0, 0.156, 0.462, 0.752, 0.955, 1.062, 1.094, 1.083, 1.055, 1.027, 1.006, 0.995, 0.991, 0.992, 0.994, 1)',
        'command-bar-backdrop-in': 'fade-in 0.2s ease-out',
        'fade-in-up': 'fade-in-up 0.3s ease-out',
        'command-bar-out': 'command-bar-out 0.15s ease-in forwards',
        'fade-out': 'fade-out 0.15s ease-in forwards',
      },
    },
  },
};
